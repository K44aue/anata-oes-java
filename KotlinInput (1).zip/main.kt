fun main() {
    println("Coloca teu nome ai vai")
    val nome = readLine()

    println("Olá " + nome)

   println()
    
    println("Bota a idade")
    val idade = readLine()?.toIntOrNull()

    println()
    
    if (nome != null && idade != null) {
        
        if (idade >= 18) {
            println("já pode ser preso.")
            
        } else {
            println("Muito criança ainda.")
            
        }
    } else {
        println("Entrada inválida.")
    }
}
