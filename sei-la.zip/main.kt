fun main() {
  var x = 66
  var y = 3

  var soma = x + y
  println("soma: " + soma)

  var sub = x - y
  println("subtração: " + sub)

  var multi = x * y
  println("multiplicação: " + multi)

  var div = x / (y - 1)
  println("divisão: " + div)

  var restante = x % y
  println("restante da divisão ( x por y): " + restante)
}
